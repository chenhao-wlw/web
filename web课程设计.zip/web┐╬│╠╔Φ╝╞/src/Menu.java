public class Menu {
    private int id;
    private int pId;
    private String name;
    public String getName(){
        return name;
    }
    public void setName(String name){
        this.name=name;
    }
    public int getId(){
        return id;
    }
    public void setId(int id){
        this.id=id;
    }
    public int getpId(){
        return pId;
    }
    public void setpId(int pId){
        this.pId=pId;
    }
}
