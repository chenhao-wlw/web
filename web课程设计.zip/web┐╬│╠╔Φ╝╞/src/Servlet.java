import javax.swing.event.MenuDragMouseListener;
import javax.swing.event.MenuListener;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class Servlet extends javax.servlet.http.HttpServlet {
    protected void doPost(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, IOException {
    }
    protected void doGet(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, IOException {
    request.setCharacterEncoding("utf-8");
        List<Menu> menuList=new ArrayList<Menu>();
        Connection conn=null;
        PreparedStatement ps=null;
        ResultSet rs=null;
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn- DriverManager.getConnection(url:"jdbc:mysql://127.0.0.1:3306/personnel?serverTimezone=UTC",user:"root",password:"123456Aa");
            String sql="select * from menu";
            ps=conn.prepareStatement(sql);
            rs=ps.executeQuery();
            while (rs.next()){
                Menu m=new Menu();
                int columnIndex;
                m.setId(rs.getInt(columnIndex:1));
                m.setpId(rs.getInt(columnIndex:2));
                m.setName(rs.getString(columnIndex:3));
                menuList.add(m);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
