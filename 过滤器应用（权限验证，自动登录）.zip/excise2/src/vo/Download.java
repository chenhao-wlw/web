package vo;

public class Download {
    private int id;
    private String name;
    private String path;
    private String description;
    private long size;
    private String image;
    private String time;
    private String sizeStr;


    public void sizeStr(String sizeStr) {
    }
}
