package controller;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.logging.Filter;

public class permissionCheckFilter implements Filter {
    private String notCheckPath;
    @Override
    public void destory{
    }
    public void doFilter(ServletRequest req, ServletResponse resp,
                         FilterChain chain) throws IOException, ServletException{
        HttpServletRequest request=(HttpServletRequest) req;
        String path= request.getServletPath();
        System.out.println("请求地址url-pattren"+path);
        if(notCheckPath.indexOf(path)==-1){
            HttpSession session= request.getSession();
            if(session.getAttribute("currentUser")==null)
            {
                request.setAttribute("info","没有权限访问");
                request.getRequestDispatcher("/error.jsp").forward(request,resp);
            }else{
                chain.doFilter(req,resp);
            }
        }else{
            chain.doFilter(req,resp);
        }
    }
    @Override
    public void init(FilterConfig config) throws ServletException {
        notCheckPath=config.getInitParameter("notChechkPath");
    }
}
