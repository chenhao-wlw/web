function filProvince() {
    $.ajax({
        type:"post",
        url:"queryProvinceCity.do",
        data:{},
        success:function (response) {
            var provinceElement=document.getElementById("province");
            provinceElement.options.length=0;
            provinceElement.add(new Option("请选择省份",""));
            for(index=0;index<response.length;index++){
                provinceElement.add(new Option(response[index].provinceName,
                    response[index].provinceCode));
            }
        }
    });

}