function changeImg(){
    document.getElementById("vcodeImg").src="createVerifyImage.do?t="+Math.random();
}
var xmlHttp;
function createXmlHttp() {
    if(window.XMLHttpRequest){
        xmlHttp=new XMLHttpRequest();
    }else{
        xmlHttp=new ActiveXObject("Microsoft.XMLHTTP");
    }
}
var userName_correct=false;
var password_correct=false;
var vocode_correct=false;
function ajaxCheckLogin() {
    if(!userName_correct||!password_correct||!vocode_correct){
        $("#userName").blur();
        $("#password").blur();
        $("#vcode").blur();
        return;
    }
}
var userName=document.getElementById("userName").value;
var password=document.getElementById("password").value;
var vcode=document.getElementById("vcode").value;
var data="userName="+userName+"&password="+password+"&vocde="+vcode;
if(document.getElementById("autoLogin").checked)
    data=data+"&autoLogin=y";
createXmlHttp();
xmlHttp.open("past","ajaxLoginCheck.do",true);
xmlHttp.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
xmlHttp.send(data);
xmlHttp.onreadystatechange=function(){
    if(xmlHttp.readyState==4&&xmlHttp.status==200){
        var response=xmlHttp.responseText;
        var json=JSON.parse(response);
        if(json.code==0){
            window.location.href="main.jsp";
        }else{
            document.getElementById("checkError").innerText==json.info;
        }
    }
}