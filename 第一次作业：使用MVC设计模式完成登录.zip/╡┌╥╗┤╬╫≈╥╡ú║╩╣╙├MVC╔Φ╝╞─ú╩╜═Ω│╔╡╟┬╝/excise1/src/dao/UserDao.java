package dao;

import vo.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.net.ConnectException;
import java.sql.Connection;
import java.sql.DriverManager;

@WebServlet(name = "UserDao")
public class UserDao extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    User user = null;
    try{
        Class.forName("com.mysql.jdbc.Driver");
        Connection con= DriverManager.getConnection(
                "jdbc:mysql://127.0.0.1:3306/excrise?useunicode=true&character=utf-8",root,123456Aa
        );
        String sql="select * from t_user where username=?"
                preparedStatement pst=con.prepareStatement(sql);
        pst.setString rs=pst.executeQuery();
        if(rs.next()){
            user=new User(rs.getString("username")),
            rs.getString("password"),
            rs.getString("chrname"),rs.getString("role"));
        }
        con.close();
    }
    catch (Exception e){
        e.printStackTrace();
    }
    return user;
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
