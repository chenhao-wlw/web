package controller;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.FileInputStream;
import java.io.IOException;

@WebServlet(name = "getDownloadList")
public class getDownloadList extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    String path=request.getServletContext().getRealPath("/web/计算机网络 谢希仁 第七版.pdf")
    String filename=path.substring(path.lastIndexOf("\\")+1);
    response.setHeader("context-disposition","attachment;filename=+URLEncoder.encode(filename,"UTF-8)");
        Object inputStream;
        inputStream in =new FileInputStream(path);
        int len=0;
        byte[] buffer=new byte[2014];
        ServletOutputStream out=response.getOutputStream();
        while((len=in.read(buffer))!=-1){}
        out.write(buffer,0,len);
    }
    in.close();
    out.close();

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
