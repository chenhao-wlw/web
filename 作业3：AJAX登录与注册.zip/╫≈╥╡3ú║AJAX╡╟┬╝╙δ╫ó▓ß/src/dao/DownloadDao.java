package dao;

import vo.Download;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.DecimalFormat;
import java.util.ArrayList;

public class DownloadDao {
    public ArrayList<DownloadDao> query(){
        ArrayList<DownloadDao> list = new ArrayList<Download>();
        try{
            Class.forName("com.mysql.jdbc.Driver");
            Connection con= DriverManager
                    .getConnection("" +
                            "jdbc:mysql://localhost:3306/excise?userunicode&character=utf-8",
                            "root","123456");
            String sql="select *from t_downloadList";
            PreparedStatement pst=con.prepareStatement(sql);
            ResultSet rs=pst.executeQuery();
            while(rs.next()){
                Download download =new Download();
                download.setId(rs.getInt("id"));
                download.setName(rs.getString("name"));
                download.setPath(rs.getString("path"));
                download.setDescripation(rs.getString("description"));
                long size =rs.getLong("size");
                String sizeStr=fileSizeTransfer(size);
                download.sizeStr(sizeStr);
                download.setStar(rs.getInt("star"));
                download.setImage(rs.getString("time"));
                list.add(download);
            }
            con.close();
        }
        catch (Exception e){
            e.printStackTrace();
        }
        return list;
    }

    public Download get(int id) {
        Download download =null;
        try{
            Class.forName("com.mysql.jdbc.Driver");
            Connection con=DriverManager
                    .getConnection(
                            "jdbc:mysql://localhost:3306/excise?userunicode&character=utf-8"
                            ,"root","123456"
                    );
            String sql="select *from t_downloadList where id=?";
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setInt(1,id);
            ResultSet rs=pst.executeQuery();
            if(rs.next()){
                download = new Download();
                download.setId(rs.getInt("id"));
                download.setName(rs.getString("name"));
                download.setPath(rs.getString("path"));
                download.setDescripation(rs.getString("description"));
                long size =rs.getLong("size");
                String sizeStr=fileSizeTransfer(size);
                download.sizeStr(sizeStr);
                download.setStar(rs.getInt("star"));
                download.setImage(rs.getString("time"));
                download.setSizeStr(sizeStr);
            }
            con.close();
        }
        catch (Exception e){
            e.printStackTrace();
        }
        return download;
    }
    public  String fileSizeTransfer(long fileSize){
        String mFileSize;
        DecimalFormat df= new DecimalFormat("######0.00");
        double size=(double) fileSize;
        if(size>1024*1024*1024){
            size=size/(1024*1024*1024);
            mFileSize=df.format(size)+"G";
        }else if(size>1024*1024){
            size=size/(1024*1024);
            mFileSize=df.format(size)+"MB";
        }else if(size>1024)
        {
            size=size/1024;
            mFileSize=df.format(size)+"KB";
        }else{
            mFileSize=df.format(size)+"B";
        }
        return mFileSize;
    }
}
