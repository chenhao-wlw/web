package controller;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet(name = "/login.do")
public class LoginController extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    request.setCharacterEncoding("utf-8");
    String username = request.getParameter("username");
    String password = request.getParameter("password");
    String vcode = request.getParameter("vcode");
        HttpSession session = request.getSession();
        String saveVcode = (String) session.getAttribute("verifycode");
        String forwarPath = "";
        if(!vcode.equalsIgnoreCase(saveVcode)){
            request.setAttribute("info","您输入的用户名不存在");
            forwarPath = "/error.jsp";
        }else{
            UserDao userDao = new UserDao();
            if(userDao.get(username)==null){
                request.setAttribute("info","您输入的用户名不存在");
                forwarPath="/error.jsp";
            }else{
                User currentUser=userDao.get(username,password);
                if(currentUser==null){
                    request.setAttribute("info","您输入的密码不正确");
                }else{
                    session.setAttribute("currentUser",currentUser);
                    forwarPath="/main.jsp";
                }
            }
        }
        rd=request.getRequestDispatcher(forwarPath);
        rd.forward(request,response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

    }
}
